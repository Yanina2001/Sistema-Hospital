from django.db import models
from django.contrib.auth.models import User



departments=[('Anatomía Patológica','Anatomía Patológica'),
('Alergología','Alergología'),
('Cardiología','Cardiología'),
('Cirugía Cardiovascular','Cirugía Cardiovascular'),
('Cirugía General','Cirugía General'),
('Cirugía Plástica','Cirugía Plástica'),
('Cirugía de Mama','Cirugía de Mama'),
('Cirugía Maxilofacial','Cirugía Maxilofacial'),
('Cirugía Vascular','Cirugía Vascular'),
('Dermatología','Dermatología'),
('Endocrinología y Nutrición','Endocrinología y Nutrición'),
('Gastroenterología','Gastroenterología'),
('Genética','Genética'),
('Geriatría','Geriatría'),
('Ginecología','Ginecología'),
('Hematología','Hematología'),
('Hepatología','Hepatología'),
('Enfermedades Infecciosas','Enfermedades Infecciosas'),
('Medicina Interna','Medicina Interna'),
('Nefrología','Nefrología'),
('Neumología','Neumología'),
('Neurología','Neurología'),
('Neurocirugía','Neurocirugía'),
('Oftalmología','Oftalmología'),
('Otorrinolaringología','Otorrinolaringología'),
('Oncología','Oncología'),
('Pediatría','Pediatría'),
('Proctología','Proctología'),
('Psiquiatría','Psiquiatría'),
('Rehabilitación y Medicina Deportiva','Rehabilitación y Medicina Deportiva'),
('Reumatología','Reumatología'),
('Traumatología','Traumatología'),
('Urología','Urología')
]
class Doctor(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    profile_pic= models.ImageField(upload_to='profile_pic/DoctorProfilePic/',null=True,blank=True)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20,null=True)
    department= models.CharField(max_length=50,choices=departments,default='Cardiologist')
    status=models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return "{} ({})".format(self.user.first_name,self.department)



class Patient(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    profile_pic= models.ImageField(upload_to='profile_pic/PatientProfilePic/',null=True,blank=True)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20,null=False)
    symptoms = models.CharField(max_length=100,null=False)
    assignedDoctorId = models.PositiveIntegerField(null=False)
    admitDate=models.DateField(auto_now=True)
    status=models.BooleanField(default=False)

    EnferDiag = models.CharField(max_length=40,null=False)
    MedEnferDiag = models.CharField(max_length=40)
    Alergias = models.CharField(max_length=40)
    AnteFam = models.CharField(max_length=40)
    x = models.CharField(max_length=40)


    
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return self.user.first_name+" ("+self.symptoms+")"


class Appointment(models.Model):
    patientId=models.PositiveIntegerField(null=False)
    doctorId=models.PositiveIntegerField(null=False)
    patientName=models.CharField(max_length=40,null=True)
    doctorName=models.CharField(max_length=40,null=True)
    appointmentDate=models.DateField(auto_now=True)
    description=models.TextField(max_length=500)
    status=models.BooleanField(default=False)



class PatientDischargeDetails(models.Model):
    patientId=models.PositiveIntegerField(null=False)
    patientName=models.CharField(max_length=40)
    assignedDoctorName=models.CharField(max_length=40)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20,null=True)
    symptoms = models.CharField(max_length=100,null=True)

    admitDate=models.DateField(null=False)
    releaseDate=models.DateField(null=False)
    daySpent=models.PositiveIntegerField(null=False)

    roomCharge=models.PositiveIntegerField(null=True)
    medicineCost=models.PositiveIntegerField(null=True)
    doctorFee=models.PositiveIntegerField(null=False)
    OtherCharge=models.PositiveIntegerField(null=False)
    total=models.PositiveIntegerField(null=False)


